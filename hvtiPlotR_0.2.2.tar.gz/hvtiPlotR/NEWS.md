# hvtiPlotR 0.2.2

* Fixed deprecated ggplot2 syntax (size -> linewidth in element_line and element_rect)
* Removed empty save.hviplotr function
* Fixed theme_dark_ppt to pass all parameters to theme_grey
* Updated documentation for data objects
* Updated README to reference officer package instead of deprecated ReporteRs

# hvtiPlotR 0.2.0

* Initial CRAN submission.
