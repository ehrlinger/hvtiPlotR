# Tests for makeFootnote function
context("makeFootnote tests")

test_that("makeFootnote executes without error", {
  skip_if_not_installed("grid")

  # Create a simple plot
  plot(1:10)

  # Test that makeFootnote runs without error
  expect_error(makeFootnote(), NA)
  expect_error(makeFootnote(timestamp = FALSE), NA)
  expect_error(makeFootnote("Custom footnote", size = 0.8), NA)
})

test_that("makeFootnote accepts custom parameters", {
  skip_if_not_installed("grid")
  skip_if_not_installed("grDevices")

  plot(1:10)

  expect_error(
    makeFootnote("Test", size = 0.5, color = "red", timestamp = FALSE),
    NA
  )
})
