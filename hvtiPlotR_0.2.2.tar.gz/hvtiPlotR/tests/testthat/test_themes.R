# Tests for theme functions
context("Theme tests")

test_that("theme_ppt returns a valid theme object", {
  skip_if_not_installed("ggplot2")
  theme <- theme_ppt()
  expect_s3_class(theme, "theme")
  expect_s3_class(theme, "gg")
})

test_that("theme_manuscript returns a valid theme object", {
  skip_if_not_installed("ggplot2")
  theme <- theme_manuscript()
  expect_s3_class(theme, "theme")
  expect_s3_class(theme, "gg")
})

test_that("theme_man is an alias for theme_manuscript", {
  skip_if_not_installed("ggplot2")
  expect_identical(theme_man, theme_manuscript)
})

test_that("theme_dark_ppt returns a valid theme object", {
  skip_if_not_installed("ggplot2")
  theme <- theme_dark_ppt()
  expect_s3_class(theme, "theme")
  expect_s3_class(theme, "gg")
})

test_that("theme_poster returns a valid theme object", {
  skip_if_not_installed("ggplot2")
  theme <- theme_poster()
  expect_s3_class(theme, "theme")
  expect_s3_class(theme, "gg")
})

test_that("theme functions accept custom parameters", {
  skip_if_not_installed("ggplot2")
  theme <- theme_ppt(base_size = 20, ink = "red")
  expect_s3_class(theme, "theme")

  theme2 <- theme_manuscript(base_size = 14, paper = "gray90")
  expect_s3_class(theme2, "theme")
})
