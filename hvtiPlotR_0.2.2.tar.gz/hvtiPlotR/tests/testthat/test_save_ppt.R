# Tests for save_ppt function
context("save_ppt tests")

test_that("save_ppt validates input types", {
  skip_if_not_installed("ggplot2")
  skip_if_not_installed("officer")

  # Create a simple ggplot object
  library(ggplot2)
  p <- ggplot(data.frame(x = 1:10, y = 1:10), aes(x, y)) + geom_point()

  # Test that function accepts ggplot objects
  expect_error(
    save_ppt(p, template = tempfile(fileext = ".pptx"),
             powerpoint = tempfile(fileext = ".pptx")),
    NA  # Expect no error, though file operations may fail
  )
})

test_that("save_ppt accepts list of ggplot objects", {
  skip_if_not_installed("ggplot2")
  skip_if_not_installed("officer")

  library(ggplot2)
  p1 <- ggplot(data.frame(x = 1:10, y = 1:10), aes(x, y)) + geom_point()
  p2 <- ggplot(data.frame(x = 1:10, y = 10:1), aes(x, y)) + geom_line()

  plot_list <- list(p1, p2)

  # Test that function accepts list of ggplot objects
  expect_error(
    save_ppt(plot_list, template = tempfile(fileext = ".pptx"),
             powerpoint = tempfile(fileext = ".pptx")),
    NA  # Expect no error, though file operations may fail
  )
})
