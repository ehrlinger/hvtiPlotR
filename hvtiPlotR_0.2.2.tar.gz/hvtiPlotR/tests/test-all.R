library(testthat)

test_check("hvtiPlotR")